# Brief Claude Design — Denkma

**Comment l'utiliser** : copie-colle la section « Prompt à envoyer » ci-dessous dans Claude Design (claude.ai → Claude Design). Attache aussi : `landing/assets/logo.png`, les variantes logo de la racine (`denkma_logo_*.png`), et une capture de `landing/index.html` actuelle.

---

## Prompt à envoyer

> Je veux refondre la landing page de **Denkma**, une plateforme sénégalaise de livraison et de points relais. Objectif : convertir les visiteurs en téléchargements d'app (Android / iOS bientôt disponibles) et en candidatures partenaires (livreurs, commerces relais).
>
> ### Contexte produit
> - **Pays** : Sénégal (Dakar en priorité, FR fr-SN)
> - **Utilisateurs** : clients (expéditeurs / destinataires), livreurs, points relais (commerces partenaires), admins
> - **Différenciateur** : 4 modes de livraison — domicile↔domicile, domicile↔relais, relais↔domicile, relais↔relais
> - **Prix d'appel** : à partir de **700 XOF** (relais↔relais) jusqu'à 1 300 XOF (domicile↔domicile), + km + kg + express
> - **Preuves de confiance** : suivi temps réel, code PIN de retrait, notifications WhatsApp, preuves photo livreur
> - **Paiement** : Wave, Orange Money, Free Money (via Flutterwave) + cash à la livraison
>
> ### Identité visuelle (à appliquer strictement)
> - **Primary** : `#0b8a5f` (vert Denkma) — CTA, icônes, accents forts
> - **Primary dark** : `#076e4b` — hover, gradients
> - **Primary soft** : `#e6f5ef` — backgrounds pilules / icônes
> - **Accent** : `#ffb703` (jaune safran) — badges "nouveau", highlights
> - **Dark** : `#0f1b17` (footer), texte `#1a1a1a`, muted `#555`
> - **Typo** : moderne sans-serif (Inter ou Manrope), titres 700-800 avec letter-spacing légèrement serré
> - **Ton** : chaleureux, concret, fier (Dakar / Sénégal), zéro jargon tech
> - **Iconographie** : Lucide / Feather (stroke 1.75-2, lineCap round)
> - **Ambiance** : moderne africaine — éviter clichés "safari", favoriser Dakar urbain (mobylettes, marchés, tissus wax subtils en motifs, pas en photos)
>
> ### Objectif n°1 — une page **VIVANTE**, pas un catalogue statique
> La version actuelle est correcte mais morte : fond blanc, blocs figés, aucun mouvement, zéro émotion. Je veux une page qui **raconte une histoire en scrollant** et qui donne envie de télécharger l'app dès les 3 premières secondes. Motion design soigné, pas gadget.
>
> ### Sections souhaitées (dans cet ordre)
> 1. **Hero animé**
>    - Titre qui apparaît mot par mot (stagger fade-in)
>    - Illustration SVG animée à droite : un **colis qui voyage** d'une maison vers un point relais vers une autre maison, avec un trait pointillé qui se dessine progressivement (SMIL ou CSS keyframes). Loop toutes les 6-8 s.
>    - En arrière-plan : **gradient doux qui respire** (lent shift vert → vert foncé, cycle 20 s), et motif wax en opacité 5 % qui défile lentement en parallax
>    - 2 CTA : primary (Télécharger) avec **pulse léger** toutes les 3 s ; secondary (Devenir partenaire)
>    - Badge de confiance animé en dessous : compteur qui monte ("0 → 1 247 colis livrés") au chargement
> 2. **Ticker défilant** (après hero) — bande fine avec marquee : "Dakar · Pikine · Guédiawaye · Rufisque · Thiès · Touba · Saint-Louis…" pour montrer la couverture géographique
> 3. **Comment ça marche** (4 étapes) — chaque étape s'anime à l'apparition (scroll-triggered), icônes qui **dessinent leur tracé** (stroke-dasharray animé). Flèches de liaison entre étapes qui se dessinent au scroll.
> 4. **4 modes de livraison** — cards avec flux **maison → relais** animé au hover (icônes qui se déplacent, trait pointillé qui avance). Afficher prix de base : **700 / 900 / 1 100 / 1 300 XOF**. Badge "Le + économique" sur relais↔relais, badge "Le + rapide" sur domicile↔domicile.
> 5. **Carte du Sénégal interactive** — silhouette SVG du pays avec **pins qui apparaissent un par un** (Dakar, Thiès, Saint-Louis, Touba…) avec effet radar ping autour de chaque pin. Compteur "X relais partenaires" qui s'incrémente en face.
> 6. **Pour qui** (3 cards animées) — clients / livreurs / relais. Chaque card bascule en 3D légèrement au hover (transform rotateY 3-5°). CTA différencié par audience.
> 7. **Preuves sociales vivantes**
>    - **3 compteurs animés** au scroll (colis livrés / livreurs actifs / relais partenaires) — effet counter-up
>    - **Témoignages en carrousel auto** (3 avatars placeholders + étoiles, rotation toutes les 5 s avec fade)
> 8. **Fonctionnalités** (grille 6) — icônes avec **micro-animations loop** (ex. cloche qui sonne, œil qui cligne pour suivi, QR qui scanne). Hover = glow vert.
> 9. **FAQ accordion** — ouverture smooth (max-height transition + chevron qui tourne)
> 10. **CTA final + download** — background gradient **animé en conic-gradient** qui tourne lentement derrière. Badges Google Play / App Store (mention "bientôt disponible").
> 11. **Footer** — liens produit, légal (privacy / terms), contact, réseaux sociaux
>
> ### Motion design — règles à respecter
> - **Scroll-triggered** : chaque section fade + translate-y 20px → 0 à l'apparition (Intersection Observer, 600 ms ease-out)
> - **Stagger** : dans une grille, chaque enfant a 80 ms de delay de plus que le précédent
> - **Hover** : transforme + ombre colorée vert (pas de box-shadow gris triste)
> - **Durées** : 200-400 ms pour les hovers, 600-800 ms pour les entrées de section, 3-8 s pour les loops ambiants
> - **Easing** : `cubic-bezier(0.4, 0, 0.2, 1)` par défaut, bounce léger sur les compteurs
> - **`prefers-reduced-motion`** : désactiver tous les loops ambiants et ticker, garder uniquement les fondus simples — **non négociable pour l'accessibilité**
>
> ### Contraintes
> - **Mobile-first** (80 % du trafic sera mobile) — les animations doivent rester **fluides sur Android entrée de gamme** (pas de blur backdrop lourd, pas de shadow multiples)
> - **Performance** : SVG inline + CSS animations (pas de librairie JS lourde type GSAP sauf si vraiment nécessaire). Lottie accepté pour 1-2 éléments hero max.
> - **Accessibilité** : contrastes AA minimum, focus visible sur CTA, `prefers-reduced-motion` respecté
> - **SEO** : structure sémantique (h1 unique, h2 par section), microdata conservé (la version actuelle a schema.org FAQ + Organization + SoftwareApplication — à garder)
> - **i18n** : texte en français (fr-SN), devises en XOF
>
> ### Export attendu
> HTML/CSS inline exportable vers **Claude Code** — je l'intégrerai ensuite dans `landing/index.html` du repo Denkma.

---

## Checklist à préparer avant d'envoyer

- [ ] Logo PNG haute résolution (utiliser `denkma_logo_store_app_1024_centered.png`)
- [ ] Logo transparent (`denkma_logo_proposal_1_clean_transparent.png`)
- [ ] Capture d'écran de la landing actuelle (contre-exemple pour qu'il évite les mêmes faiblesses)
- [ ] 2-3 captures réelles de l'app Flutter (écran création colis, suivi, carte drivers) — permettent à Claude Design de générer un mockup de téléphone crédible
- [ ] Palette exacte (déjà dans le brief)

## Itérations prévues après la v1

1. Ajuster la densité d'info mobile (souvent trop longue en v1)
2. Tester une variante **hero avec vidéo** vs **hero avec mockup**
3. Générer une version **partenaire commerce relais** dédiée (sous-page `/relais`)
4. Générer une version **recrutement livreurs** dédiée (sous-page `/livreurs`)
5. Exporter en HTML → je l'intègre dans `landing/` via Claude Code et j'ajoute les liens légaux `/privacy` et `/terms`

## Sous-produits à lancer ensuite dans Claude Design

- **Pitch deck investisseurs** (source : `docs/BUSINESS_PLAN_DENKMA_2026.md`) — format PPTX, 12-15 slides
- **One-pager recrutement livreurs** (PDF A4, imprimable, à distribuer dans les stations Wave)
- **One-pager recrutement relais** (PDF A4, pour démarcher les boutiques)
- **Mockups écrans app** (à valider avant développement Flutter des nouvelles features promotions / récompenses — cf. `PLAN_RECOMPENSES_PROMOTIONS.md`)
